#here the message to encrypt
echo meet at the MET
ech this is an error
