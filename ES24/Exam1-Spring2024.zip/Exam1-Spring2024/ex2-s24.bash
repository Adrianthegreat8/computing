

for i in    
do
  echo $i
  .


paste
