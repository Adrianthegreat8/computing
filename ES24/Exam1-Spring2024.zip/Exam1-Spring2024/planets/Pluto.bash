echo 0.071
