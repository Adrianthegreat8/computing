echo 0.378
