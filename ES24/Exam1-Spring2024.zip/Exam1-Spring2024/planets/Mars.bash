echo 0.377
