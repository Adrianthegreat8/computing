echo 0.889

