#mprocop2:09/27/2022:script1.bash
ech this is my location
pw
