echo This is script10
