echo this is script

