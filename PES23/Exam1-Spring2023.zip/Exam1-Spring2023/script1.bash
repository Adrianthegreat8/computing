echo this is script1.bash
pw
ech
