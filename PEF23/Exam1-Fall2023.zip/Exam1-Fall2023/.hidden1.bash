echo This is the output of the hidden file
ech  here we have an error
