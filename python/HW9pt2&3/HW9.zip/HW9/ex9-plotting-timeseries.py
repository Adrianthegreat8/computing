
files=['Carbon dioxide emission-MTCO2e.txt','Land Temperature Anomalies-Celsius.txt',
       'Labor Force Statistics-percent.txt', 'Supercomputer power-FLOPS.txt']



    

