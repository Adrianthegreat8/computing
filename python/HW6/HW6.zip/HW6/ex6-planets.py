
name=['MERCURY', 'VENUS', 'EARTH', 'MARS', 'JUPITER', 'SATURN', 'URANUS', 'NEPTUNE', 'PLUTO'] 

temp=[167, 464, 15, -65, -110, -140, -195, -200, -225] 

orb_vel=[47.4,35.0,29.8,24.1,13.1,9.7,6.8,5.4,4.7] 

num_moons=[0,0,1,2,92,83,27,14,5] 