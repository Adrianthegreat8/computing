#ex10-chemistry

D={'Compound': ['Water', 'Ethanol', 'Carbon dioxide', 'Ammonia', 'Methane'],
    'Molecular Weight (g/mol)': [18.015, 46.07, 44.01, 17.031, 16.043],
    'Boiling Point (C)': [100, 78.37, -78.5, -33.34, -161.5],
    'Organic': [False, True, False, False, True]}







