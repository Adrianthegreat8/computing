# ex10-cities.py

D = {'New York': 8500000,
    'Los Angeles': 4000000,
    'Chicago': 2700000,
    'Houston': 2300000,
    'Phoenix': 1600000,
    'Philadelphia': 1500000,
    'San Antonio': 1400000,
    'San Diego': 1300000,
    'Dallas': 1200000}





