

## source https://nssdc.gsfc.nasa.gov/planetary/factsheet/

Dplanets={'MERCURY': ['170640', 167], 'VENUS': ['126000', 464], 'EARTH': ['107280'],
   'MARS': ['86760', -65],'JUPITER': ['47160', -110], 'SATURN': ['34920', -140],
   'URANUS': ['24480', -195], 'NEPTUNE': ['19440', -200], 'PLUTO': ['16920', -225]}

L=['s', 'p', 'a', 'c', 'e']

