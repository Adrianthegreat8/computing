

Laz=['***','temperature anomaly AZ']

L=['Nevada','Colorado','Colorado']

L1=["New Mexico", 'Utah',"California"]

D={'California':[1.23,1.13,1.34,1.52, 1.46,1.98],'Colorado':[1.28,1.80,1.57,1.45]}

DNA='aca##a#g#atg##c#attgt'

Dchem={'hydrogen': ['H', 3], 'helium': ['He', 2], 'lithium':['Li', 3],'Adamantium':['Ad',22]}
