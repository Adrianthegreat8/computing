

Laz=['***','temperature anomaly AZ',1.60,1.48,1.78,1.80,1.88,1.90,1.50]

Tstate=('A~r`i^z@o>n#a', 'Nevada','Colorado','Colorado')

D={1:'This', 2:'is', 3:'an interactive', 4: 'script.'}

T=("Hello,","no sense", "this is the end.")     

Dprot={'prot1':{'code':'GATTACA'},'prot2':['ACATTA',34,56,78],'prot3':('DNA','RNA')}





