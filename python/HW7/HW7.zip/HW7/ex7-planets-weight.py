#write class header here

D={"venus":0.9,"mars":0.38,"mercury":0.38,"jupiter":2.36,
   "saturn":0.92,"uranus":0.89,"neptune":1.13,"pluto":0.07}
