
names=['emissions.txt','labor.txt','land.txt','supercomputer.txt']


