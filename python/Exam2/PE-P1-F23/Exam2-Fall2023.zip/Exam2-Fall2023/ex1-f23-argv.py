
D={'colors': ['blue','red','yellow'],'numbers': [{'integer':[1,2,3]} , {'float':[1.2,3.4]}]}


