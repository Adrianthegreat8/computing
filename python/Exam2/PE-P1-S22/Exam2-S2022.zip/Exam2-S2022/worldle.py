
#a

# your while loop should be here and should incorporate the input function provided below.                         
# if you cannot do this, leave your partial code as a comment                                        
# and just use the input functon as it is.

x = input('Please input a 5-character word: ')



#b 
user = list(x)

word = 'exams'
target = list(word)

guess = list('-'*5)
notinword = []
                                                                                           
# Your for loop should be here





#c
