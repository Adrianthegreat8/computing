
d1 = {'What':1,'is':2,'always':3}

s1 = 'IN:FRONT:OF:YOU'

l1 = ['cannot','but']

l2 = ['be','!','seen','?']

d2 = {'Almost':['The','end'],'there':{'before' : 'past', 'after' : 'future'}}


