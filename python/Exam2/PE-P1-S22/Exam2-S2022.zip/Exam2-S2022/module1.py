
""" This module provide fucntions to calculate efficiencies of a heat engine
"""

"""
honor sentence
"""

def convert(Tc):
     'Converts temperature in Celsius to temperature in Kelvin'
     Tk=Tc+273
     return Tk


def names():
     'Returns two strings: Carnot and Curzon'
     return 'Carnot','Curzon'

     
     
