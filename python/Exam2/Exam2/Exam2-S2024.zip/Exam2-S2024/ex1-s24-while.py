

L=['purple','orange','white','black','yellow',
   'red','purple','orange','white','black','yellow', 'red']


