echo this is scriptA
