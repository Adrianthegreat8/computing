#mprocop2:01/25/2022:Example.bash

#Q1
cat file1.txt

#Q2
more file1.txt





