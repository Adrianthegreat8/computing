echo this is the program script

ech This is a mistake

