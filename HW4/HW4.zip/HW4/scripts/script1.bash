echo I\'m not an hidden file ':-('
