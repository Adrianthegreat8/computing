echo this is script1
lop mistake
