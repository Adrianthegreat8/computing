echo this is script2
lops2 mistake
