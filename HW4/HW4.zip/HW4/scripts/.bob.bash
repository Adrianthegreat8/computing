echo this is the bob file
ops mistake
