echo this is the pop1 file
pw
