echo Today is\#a beautiful day
ech Error
